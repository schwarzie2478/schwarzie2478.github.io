// Treasure Hunter PWA helpers. Exposed on window for ServiceWorkerRegistrar
// and any UI that wants to pre-cache the card images for offline play.

(function () {
    'use strict';
    try {

    // The 47 card image URLs the app uses. Hand-curated to match the
    // cards/ directory; keep in sync if cards are added or renamed.
    const CARD_URLS = [
        '/cards/Boons/Boon%20Base%20Camp.png',
        '/cards/Boons/Boon%20Climbing%20rope.png',
        '/cards/Boons/Boon%20Flashlight.png',
        '/cards/Boons/Boon%20Local%20Guide.png',
        '/cards/Boons/Boon%20Map.png',
        '/cards/Cardbacks/Number%20Card%20Back.png',
        '/cards/Cardbacks/Boon%20Card%20Back.png',
        '/cards/Number/01-blue-dagger.png',
        '/cards/Number/01-grey-skull.png',
        '/cards/Number/01-red-diamond.png',
        '/cards/Number/02-blue-dagger.png',
        '/cards/Number/02-grey-skull.png',
        '/cards/Number/02-red-diamond.png',
        '/cards/Number/03-blue-dagger.png',
        '/cards/Number/03-grey-skull.png',
        '/cards/Number/03-red-diamond.png',
        '/cards/Number/04-blue-dagger.png',
        '/cards/Number/04-grey-skull.png',
        '/cards/Number/04-red-diamond.png',
        '/cards/Number/05-blue-dagger.png',
        '/cards/Number/05-grey-skull.png',
        '/cards/Number/05-red-diamond.png',
        '/cards/Number/06-blue-dagger.png',
        '/cards/Number/06-grey-skull.png',
        '/cards/Number/06-red-diamond.png',
        '/cards/Number/07-blue-dagger.png',
        '/cards/Number/07-grey-skull.png',
        '/cards/Number/07-red-diamond.png',
        '/cards/Number/08-blue-dagger.png',
        '/cards/Number/08-grey-skull.png',
        '/cards/Number/08-red-diamond.png',
        '/cards/Number/09-blue-dagger.png',
        '/cards/Number/09-grey-skull.png',
        '/cards/Number/09-red-diamond.png',
        '/cards/Number/10-blue-dagger.png',
        '/cards/Number/10-grey-skull.png',
        '/cards/Number/10-red-diamond.png',
        '/cards/Number/1%20Card%20Skull%20Card%20Coin.png',
        '/cards/Number/10%20Card%20Totem%20Coin.png',
        '/cards/Number/2%20Card%20Luggage%20Coin.png',
        '/cards/Number/3%20Card%20Skull%20Card%20Coin.png',
        '/cards/Number/4%20Card%20Luggage%20Coin.png',
        '/cards/Number/5%20Card%20Skull%20Card%20Coin.png',
        '/cards/Number/6%20Card%20Luggage%20Coin.png',
        '/cards/Number/7%20Card%20Skull%20Card%20Coin.png',
        '/cards/Number/8%20Card%20Luggage%20Coin.png',
        '/cards/Number/9%20Card%20Skull%20Card%20Coin.png',
    ];

    function getRegistration() {
        if (!('serviceWorker' in navigator)) return Promise.resolve(null);
        return navigator.serviceWorker.getRegistration();
    }

    // Pre-cache every card image so the app is fully playable offline.
    // Returns a promise that resolves when the SW has finished warming.
    function preCacheAllCards() {
        return getRegistration().then((reg) => {
            if (!reg || !reg.active) return null;
            return new Promise((resolve) => {
                const channel = new MessageChannel();
                let done = false;
                const finish = (payload) => {
                    if (done) return;
                    done = true;
                    resolve(payload);
                };
                channel.port1.onmessage = (e) => finish(e.data || null);
                // Safety timeout: resolve with what we know after 5 minutes
                setTimeout(() => finish({ timeout: true }), 5 * 60 * 1000);
                reg.active.postMessage(
                    { type: 'WARMUP_CARDS', urls: CARD_URLS },
                    [channel.port2]
                );
            });
        });
    }

    function getCacheStatus() {
        return getRegistration().then((reg) => {
            if (!reg || !reg.active) return null;
            return new Promise((resolve) => {
                const channel = new MessageChannel();
                const t = setTimeout(() => resolve(null), 2000);
                channel.port1.onmessage = (e) => {
                    clearTimeout(t);
                    resolve(e.data || null);
                };
                reg.active.postMessage({ type: 'CACHE_STATUS' }, [channel.port2]);
            });
        });
    }

    window.ThPwa = {
        preCacheAllCards,
        getCacheStatus,
        cardCount: CARD_URLS.length,
    };
    } catch (e) {
        console.error('[pwa-helpers] init failed:', e);
    }
})();
